/* ═══════════════════════════════════════════════
   ARROW ARCHITECT — Main JavaScript
   Author: Ajeesh | Rajajinagar, Bangalore
   ═══════════════════════════════════════════════ */

/* ─── YOUR WHATSAPP NUMBER — CHANGE THIS ─────── */
const WHATSAPP_NUMBER = "919XXXXXXXXX"; // Replace with your number e.g. "919845001234"
const WHATSAPP_MESSAGE = "Hi Ajeesh! I visited your website and I'm interested in discussing a project with Arrow Architect.";

/* ─── GOOGLE ANALYTICS — YOUR ID GOES HERE ───── */
// Replace GA_MEASUREMENT_ID in index.html with your actual ID from analytics.google.com

/* ─── NAV SCROLL EFFECT ─────────────────────── */
window.addEventListener('scroll', () => {
  const nav = document.getElementById('navbar');
  if (!nav) return;
  if (window.scrollY > 60) {
    nav.style.padding = window.innerWidth > 900 ? '12px 60px' : '12px 24px';
  } else {
    nav.style.padding = window.innerWidth > 900 ? '18px 60px' : '16px 24px';
  }
});

/* ─── MOBILE MENU ────────────────────────────── */
function toggleMenu() {
  document.getElementById('mobileMenu').classList.toggle('open');
  document.body.style.overflow = document.getElementById('mobileMenu').classList.contains('open') ? 'hidden' : '';
}

/* ─── SCROLL REVEAL ──────────────────────────── */
const observer = new IntersectionObserver((entries) => {
  entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('visible'); });
}, { threshold: 0.08 });
document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

/* ─── PORTFOLIO FILTER ───────────────────────── */
function filterPortfolio(btn, cat) {
  document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  document.querySelectorAll('.portfolio-item').forEach(item => {
    item.style.display = (cat === 'all' || item.dataset.category === cat) ? 'flex' : 'none';
  });
}

/* ─── CONTACT FORM SUBMIT ────────────────────── */
function handleSubmit() {
  const btn = document.querySelector('.submit-btn');
  btn.textContent = 'Sending…';
  btn.disabled = true;
  setTimeout(() => {
    btn.textContent = '✓ Message Sent! I\'ll be in touch shortly.';
    btn.style.background = '#C9A84C';
    btn.style.color = '#0D2E2A';
    setTimeout(() => {
      btn.textContent = 'Send Enquiry';
      btn.style.background = '';
      btn.style.color = '';
      btn.disabled = false;
    }, 5000);
  }, 1200);
}

/* ─── WHATSAPP FLOATING BUTTON ───────────────── */
function openWhatsApp() {
  const msg = encodeURIComponent(WHATSAPP_MESSAGE);
  window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${msg}`, '_blank');
}

/* ─── BOOKING CALENDAR ───────────────────────── */
const BOOKED_SLOTS = {
  // Format: "YYYY-MM-DD": ["10:00 AM", "2:00 PM"]  — add your booked times here
  "2025-04-15": ["10:00 AM", "11:00 AM"],
  "2025-04-18": ["2:00 PM", "4:00 PM"],
};

const ALL_SLOTS = ["10:00 AM", "11:00 AM", "12:00 PM", "2:00 PM", "3:00 PM", "4:00 PM", "5:00 PM", "6:00 PM"];
const UNAVAILABLE_DAYS = [0]; // 0 = Sunday closed

let currentDate = new Date();
let selectedDate = null;
let selectedSlot = null;

function renderCalendar() {
  const cal = document.getElementById('calGrid');
  const title = document.getElementById('calTitle');
  if (!cal) return;

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const today = new Date();
  today.setHours(0,0,0,0);

  const monthNames = ["January","February","March","April","May","June","July","August","September","October","November","December"];
  title.textContent = `${monthNames[month]} ${year}`;

  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  cal.innerHTML = '';

  // Empty cells for start of month
  for (let i = 0; i < firstDay; i++) {
    const cell = document.createElement('div');
    cell.className = 'cal-cell empty';
    cal.appendChild(cell);
  }

  for (let d = 1; d <= daysInMonth; d++) {
    const cell = document.createElement('div');
    const thisDate = new Date(year, month, d);
    thisDate.setHours(0,0,0,0);
    const dateStr = `${year}-${String(month+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
    const bookedCount = (BOOKED_SLOTS[dateStr] || []).length;
    const isUnavailable = UNAVAILABLE_DAYS.includes(thisDate.getDay());
    const isPast = thisDate < today;
    const isToday = thisDate.getTime() === today.getTime();
    const isSelected = selectedDate === dateStr;
    const hasSlots = !isPast && !isUnavailable && bookedCount < ALL_SLOTS.length;

    cell.textContent = d;
    cell.className = 'cal-cell';
    if (isPast || isUnavailable) cell.classList.add('past');
    else if (hasSlots) cell.classList.add('available');
    if (isToday) cell.classList.add('today');
    if (isSelected) cell.classList.add('selected');

    if (!isPast && !isUnavailable) {
      cell.onclick = () => selectDate(dateStr, cell);
    }
    cal.appendChild(cell);
  }
}

function selectDate(dateStr, cell) {
  document.querySelectorAll('.cal-cell').forEach(c => c.classList.remove('selected'));
  cell.classList.add('selected');
  selectedDate = dateStr;
  selectedSlot = null;
  renderSlots();
  document.getElementById('slotSection').style.display = 'block';
}

function renderSlots() {
  const grid = document.getElementById('slotsGrid');
  if (!grid) return;
  const booked = BOOKED_SLOTS[selectedDate] || [];
  const [y,m,d] = selectedDate.split('-');
  const monthNames = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  document.getElementById('slotsTitle').textContent = `Available times — ${parseInt(d)} ${monthNames[parseInt(m)-1]} ${y}`;
  grid.innerHTML = '';
  ALL_SLOTS.forEach(slot => {
    const btn = document.createElement('button');
    btn.className = 'slot-btn';
    btn.textContent = slot;
    if (booked.includes(slot)) {
      btn.classList.add('booked');
      btn.disabled = true;
    } else {
      btn.onclick = () => selectSlot(slot, btn);
    }
    grid.appendChild(btn);
  });
}

function selectSlot(slot, btn) {
  document.querySelectorAll('.slot-btn').forEach(b => b.classList.remove('selected'));
  btn.classList.add('selected');
  selectedSlot = slot;
}

function prevMonth() {
  currentDate.setMonth(currentDate.getMonth() - 1);
  renderCalendar();
}
function nextMonth() {
  currentDate.setMonth(currentDate.getMonth() + 1);
  renderCalendar();
}

function confirmBooking() {
  const name = document.getElementById('bookName').value.trim();
  const phone = document.getElementById('bookPhone').value.trim();
  const type = document.getElementById('bookType').value;

  if (!selectedDate) { alert('Please select a date.'); return; }
  if (!selectedSlot) { alert('Please select a time slot.'); return; }
  if (!name) { alert('Please enter your name.'); return; }
  if (!phone) { alert('Please enter your phone number.'); return; }

  const [y,m,d] = selectedDate.split('-');
  const monthNames = ["January","February","March","April","May","June","July","August","September","October","November","December"];
  const dateLabel = `${parseInt(d)} ${monthNames[parseInt(m)-1]} ${y}`;

  // Send WhatsApp confirmation
  const waMsg = encodeURIComponent(
    `📅 *New Consultation Booking — Arrow Architect*\n\n` +
    `Name: ${name}\nPhone: ${phone}\nDate: ${dateLabel}\nTime: ${selectedSlot}\nProject Type: ${type}`
  );
  window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${waMsg}`, '_blank');

  // Show success
  document.getElementById('bookingFormWrap').style.display = 'none';
  const success = document.getElementById('bookingSuccess');
  success.classList.add('show');
  success.innerHTML = `
    <div class="booking-success-icon">✓</div>
    <h3>Booking Request Sent!</h3>
    <p>Your consultation for <strong style="color:var(--gold)">${dateLabel}</strong> at <strong style="color:var(--gold)">${selectedSlot}</strong> has been sent to Ajeesh via WhatsApp.<br><br>You'll receive a confirmation shortly.</p>
  `;
}

// Init calendar on load
document.addEventListener('DOMContentLoaded', () => {
  renderCalendar();
});
